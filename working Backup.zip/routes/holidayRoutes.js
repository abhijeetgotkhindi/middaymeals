import express from 'express';
import { getAllHoliday, addNewHoliday, updateHolidayRecord, deleteHolidayRecord } from '../controllers/holidayController.js';
import { verifyToken } from "../middleware/verifyTokenMiddleware.js";
const router = express.Router();

router.get('/', verifyToken, getAllHoliday);
router.post('/addnew', verifyToken, addNewHoliday);
router.put('/update', verifyToken, updateHolidayRecord);
router.delete('/delete', verifyToken, deleteHolidayRecord);

export default router;

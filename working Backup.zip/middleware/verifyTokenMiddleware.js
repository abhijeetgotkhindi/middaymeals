import jwt from "jsonwebtoken";
export const verifyToken = (req, res, next) => {
    const token = req.cookies?.token;
    if (!token){
        return res.json({
                    status: false,
                    code: 400,
                    message: "Not authenticated"
                });
    }        // return res.status(403).json({ status: false, message: 'Not authenticated' });
    else {
        const authHeader = req.headers['authorization'];
        const auth_token = authHeader && authHeader.split(' ')[1];
        if (auth_token == null) return res.status(400).json({ status: false, message: 'Not authenticated' });
        jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
            if (err) {
                return res.status(400).json({
                    status: false,
                    message: err
                });
            }
            res.cookie('token', token, {
                httpOnly: true,
                secure: true, // Use in production (HTTPS)
                sameSite: 'Lax', // or 'Lax'
                maxAge: process.env.MAX_AGE // 1 hour
            });
            next();
        })
    }
}


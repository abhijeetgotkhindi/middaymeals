import { pool } from "../config/db.js";
import { v6 as uuidv6 } from 'uuid';

export const intentList = async (ngooid, schooloid, datefilter) => {
    const [startStr, endStr] = datefilter.split(":");
    try {
        const [intent] = await pool.query(`SELECT  i.oid as intentrow,i.oid,DATE_FORMAT(intentfor,'%a %d-%m-%Y') AS intentfor,schoolname , school
            , g1totalreg, g1totalpresent, g1milk, g1hotmeals, g1egg, g1banana, g1total
            , g2totalreg, g2totalpresent, g2milk, g2hotmeals, g2egg, g2banana, g2total
            , g3totalreg, g3totalpresent, g3milk, g3hotmeals, g3egg, g3banana, g3total
            , g4totalreg, g4totalpresent, g4milk, g4hotmeals, g4egg, g4banana, g4total
            ,m.value2 as istatus,DATE_FORMAT(i.creationtime,'%h:%i %p') as creationtime,m.value,CASE 
            WHEN i.updatedtime IS NOT NULL AND i.updatedtime > i.creationtime THEN i.updatedtime
            ELSE i.creationtime
            END AS createdDate  
            ,(g1totalpresent+g2totalpresent+g3totalpresent+g4totalpresent) as totalpresent
            ,(g1totalreg+g2totalreg+g3totalreg+g4totalreg) as totalreg            
            ,(g1hotmeals+g2hotmeals+g3hotmeals+g4hotmeals) as hotmeals
            ,(g1milk+g2milk+g3milk+g4milk) as milk
            ,(g1egg+g2egg+g3egg+g4egg) as egg
            ,(g1banana+g2banana+g3banana+g4banana) as banana
            FROM ` + ngooid + `_intent i
            INNER JOIN school s on (i.school = s.oid) 
            INNER JOIN mastersettings m ON (i.istatus = m.value and type = 'intentstatus')
            WHERE i.status = 1 AND i.status != 0 and i.school in (${schooloid})
            AND intentfor between CAST(STR_TO_DATE('${startStr}', '%d-%m-%Y') AS DATE) AND CAST(STR_TO_DATE('${endStr}', '%d-%m-%Y') AS DATE)
            ORDER BY istatus,intentfor desc`);
        if (intent.length === 0) {
            return { success: true, message: 'Data not found', intent: [] };
        }
        return {
            success: true,
            message: 'Data fetched successful',
            intent: intent
        };
    } catch (error) {
        console.error("Error:", error);
        return { success: false, message: 'Failed. Please try again later.' };
    }
};

export const insertIntent = async (datavalues, ngooid) => {
    try {
        datavalues["uuid"] = uuidv6();
        if (datavalues['istatus'] == -1)
            datavalues['drafttime'] = new Date();
        else
            datavalues['submittedtime'] = new Date()
        datavalues['creationtime'] = new Date()
        const columns = Object.keys(datavalues);
        const placeholders = columns.map(() => '?').join(', ');
        const values = Object.values(datavalues);
        const query = `INSERT INTO ${ngooid}_intent (${columns.join(', ')}) VALUES (${placeholders})`;
        const [results] = await pool.query(query, values);
        return { success: true, message: "Inserted Records: " + results.affectedRows };
    } catch (error) {
        return { success: false, message: "Error: " + error.sqlMessage };
    }
};

export const updateIntent = async (datavalues, ngooid) => {
    const { oid, istatus, createdby } = datavalues;
    if (!oid) return { success: false, message: "Missing oid for update." };

    let fields = [];
    let values = [];

    // Auto handle known fields dynamically
    const allowedFields = [
        "intentfor", "school"
        , "g1totalreg", "g1totalpresent", "g1milk", "g1hotmeals", "g1egg", "g1banana", "g1total"
        , "g2totalreg", "g2totalpresent", "g2milk", "g2hotmeals", "g2egg", "g2banana", "g2total"
        , "g3totalreg", "g3totalpresent", "g3milk", "g3hotmeals", "g3egg", "g3banana", "g3total"
        , "g4totalreg", "g4totalpresent", "g4milk", "g4hotmeals", "g4egg", "g4banana", "g4total"
        , "istatus"
    ];

    allowedFields.forEach(field => {
        if (datavalues[field] !== undefined) {
            fields.push(`${field} = ?`);
            values.push(datavalues[field]);
        }
    });

    // Special handling: add deliveredtime or receivedtime
    if (istatus == 2) {
        fields.push("deliveredtime = NOW()");
    } else if (istatus == 3) {
        fields.push("receivedtime = NOW()");
    }

    // Always include audit fields
    fields.push("updatedby = ?");
    fields.push("updatedtime = NOW()");
    values.push(createdby); // for updatedby

    // WHERE clause
    values.push(oid);

    const query = `UPDATE ${ngooid}_intent SET ${fields.join(', ')} WHERE oid = ?`;

    try {
        const [results] = await pool.query(query, values);
        return { success: true, message: "Updated Records: " + results.affectedRows };
    } catch (error) {
        return { success: false, message: "Error: " + error.sqlMessage };
    }
};

export const updateIntentStatus = async (datavalues, ngooid) => {
    const { oid } = datavalues;
    const oids = oid.split(',').map(id => id.trim());

    // Clone object to avoid modifying original
    const updateFields = { ...datavalues };

    // Handle timestamps based on istatus
    if (updateFields.istatus === 2) {
        updateFields.deliveredtime = new Date();
    } else if (updateFields.istatus === 3) {
        updateFields.receivedtime = new Date();
    }

    // Always update updatedtime
    updateFields.updatedtime = new Date();

    // Remove `oid` from fields being updated
    delete updateFields.oid;

    const keys = Object.keys(updateFields); // e.g. ['istatus', 'createdby', 'deliveredtime', 'updatedtime']
    const values = Object.values(updateFields); // Corresponding values

    // Build SET clause like "istatus = ?, createdby = ?, deliveredtime = ?, updatedtime = ?"
    const setClause = keys.map(key => `${key} = ?`).join(', ');

    try {
        const query = `UPDATE ${ngooid}_intent SET ${setClause} WHERE oid IN (?);`;
        const [results] = await pool.query(query, [...values, oids]);
        return { success: true, message: "Updated Records: " + results.affectedRows };
    } catch (error) {
        return { success: false, message: "Error: " + error.sqlMessage };
    }
};


export const deleteIntent = async (oid, ngooid) => {
    try {
        const [results] = await pool.query("UPDATE " + ngooid + "_intent SET status = 0 WHERE oid = ?", [oid]);
        return { success: true, message: "Deleted Records: " + results.affectedRows };
    } catch (error) {
        return { success: false, message: "Error: " + error.sqlMessage };
    }
};
